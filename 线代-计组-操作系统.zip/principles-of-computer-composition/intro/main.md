# 计算机组成原理简介

## 听说要考的骚点
- 国产 `CPU` 的名字
  - 龙芯（Loongson），自主研发的LoongArch架构（早期基于MIPS架构）
  - 飞腾（Phytium），基于ARM架构，天津飞腾信息技术有限公司
  - 兆芯（Zhaoxin），基于x86架构，上海兆芯集成电路有限公司
  - 海光（Hygon），基于AMD Zen架构（授权改进），海光信息技术有限公司
  - 华为昇腾（Ascend），华为技术有限公司，基于ARM架构（自主优化）

<script src="https://giscus.app/client.js"
        data-repo="SunSeaLucky/xju-course-wiki"
        data-repo-id="R_kgDONf4gSg"
        data-category="Announcements"
        data-category-id="DIC_kwDONf4gSs4ClXwK"
        data-mapping="pathname"
        data-strict="0"
        data-reactions-enabled="1"
        data-emit-metadata="0"
        data-input-position="bottom"
        data-theme="light"
        data-lang="zh-CN"
        crossorigin="anonymous"
        async>
</script>